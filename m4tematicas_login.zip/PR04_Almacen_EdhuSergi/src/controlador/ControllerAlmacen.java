/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Conexion;
import model.Persona;

/**
 *
 * @author Usuario
 */
public class ControllerAlmacen {

    public ControllerAlmacen() {
    }
    
    public DefaultTableModel mostrarProducto(){
        
        DefaultTableModel muestra = new DefaultTableModel();
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String sql = "SELECT * FROM tbl_producte";
        
        Statement st = null;
        String vectorProducto[] = new String[4];
        String vectorProducto1[] = new String[4];
        
        vectorProducto1[0] = "ID";
        vectorProducto1[1] = "Nombre";
        
                
        muestra = new DefaultTableModel(null,vectorProducto1);
        //String[] vectorProducto; 
        try {
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {
                
                vectorProducto[0] = String.valueOf(rs.getInt("prod_id"));
                vectorProducto[1] = rs.getString("prod_nom");
                //vectorProducto[2] = String.valueOf(rs.getDouble("pro_precio"));
                //vectorProducto[3] = String.valueOf(rs.getDouble("pro_stock"));
                
                muestra.addRow(vectorProducto);
            }
            
        } catch (Exception e) {
        }
        
        return muestra;
    }
    
    public int login(String usuario, String clavedef){
        
        int resultado=0;
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String sql = "SELECT * FROM tbl_personas WHERE persona_usuario='"+usuario+"' && persona_password='"+clavedef+"'";
         
         try {
            // crear el statement
            Statement st = cn.createStatement();
            // lanzar la consulta
            ResultSet rs = st.executeQuery(sql);
            //lanza consulta con "executequery"
            if(rs.next()){
                resultado=1;
            }
         
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "UPPS! no se ha podido conectar a la base de datos");
        } finally {
             try {
                 cn.close();
             } catch (Exception e) {
                 JOptionPane.showMessageDialog(null, "UPPS! no se ha podido desconectar a la base de datos");
             }
        }
        return resultado; 
    }
}
