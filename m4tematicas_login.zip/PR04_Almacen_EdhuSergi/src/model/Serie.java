/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Usuario
 */
public class Serie {
    private int serie_id;
    private String serie_nom;

    public Serie() {
    }

    public Serie(String serie_nom) {
        this.serie_nom = serie_nom;
    }

    public Serie(int serie_id, String serie_nom) {
        this.serie_id = serie_id;
        this.serie_nom = serie_nom;
    }

    public int getSerie_id() {
        return serie_id;
    }

    public String getSerie_nom() {
        return serie_nom;
    }

    public void setSerie_nom(String serie_nom) {
        this.serie_nom = serie_nom;
    }
    
    
}
