/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Usuario
 */
public class Persona {
    private int persona_id;
    private String persona_usuario;
    private String persona_password;

    //CONSTRUCTORES
    public Persona() {
    }

    public Persona(String persona_usuario, String persona_password) {
        this.persona_usuario = persona_usuario;
        this.persona_password = persona_password;
    }

    public Persona(int persona_id, String persona_usuario, String persona_password) {
        this.persona_id = persona_id;
        this.persona_usuario = persona_usuario;
        this.persona_password = persona_password;
    }

    //GETTER
    public int getPersona_id() {
        return persona_id;
    }

    public String getPersona_usuario() {
        return persona_usuario;
    }

    public String getPersona_password() {
        return persona_password;
    }

    //SETTER
    public void setPersona_id(int persona_id) {
        this.persona_id = persona_id;
    }

    public void setPersona_usuario(String persona_usuario) {
        this.persona_usuario = persona_usuario;
    }

    public void setPersona_password(String persona_password) {
        this.persona_password = persona_password;
    }
    
    
}
